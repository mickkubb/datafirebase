// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyCspJgqvKd4r3JSyoaTwccdQSmdLRm_4uA",
  authDomain: "mixkuy-748bb.firebaseapp.com",
  projectId: "mixkuy-748bb",
  storageBucket: "mixkuy-748bb.appspot.com",
  messagingSenderId: "322612468692",
  appId: "1:322612468692:web:786cda740349d01bec1441",
  measurementId: "G-QFXTFY1HWR",
});

const db = getFirestore(firebaseApp);
export default db;
